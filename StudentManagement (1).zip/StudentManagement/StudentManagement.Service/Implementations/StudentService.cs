using Microsoft.Extensions.Logging;
using StudentManagement.Domain.DTOs;
using StudentManagement.Domain.Entities;
using StudentManagement.Repository.Interfaces;
using StudentManagement.Service.Interfaces;

namespace StudentManagement.Service.Implementations;

public class StudentService : IStudentService
{
    private readonly IStudentRepository _repository;
    private readonly ILogger<StudentService> _logger;

    public StudentService(IStudentRepository repository, ILogger<StudentService> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    public async Task<IEnumerable<StudentDto>> GetAllStudentsAsync()
    {
        _logger.LogInformation("Fetching all students");
        var students = await _repository.GetAllAsync();
        return students.Select(MapToDto);
    }

    public async Task<StudentDto?> GetStudentByIdAsync(int id)
    {
        _logger.LogInformation("Fetching student with ID: {Id}", id);
        var student = await _repository.GetByIdAsync(id);
        return student == null ? null : MapToDto(student);
    }

    public async Task<StudentDto> CreateStudentAsync(CreateStudentDto dto)
    {
        _logger.LogInformation("Creating new student with email: {Email}", dto.Email);

        var existingStudent = await _repository.GetByEmailAsync(dto.Email);
        if (existingStudent != null)
            throw new InvalidOperationException($"A student with email '{dto.Email}' already exists.");

        var student = new Student
        {
            Name = dto.Name,
            Email = dto.Email,
            Age = dto.Age,
            Course = dto.Course,
            CreatedDate = DateTime.UtcNow
        };

        var id = await _repository.CreateAsync(student);
        student.Id = id;

        _logger.LogInformation("Student created successfully with ID: {Id}", id);
        return MapToDto(student);
    }

    public async Task<StudentDto> UpdateStudentAsync(int id, UpdateStudentDto dto)
    {
        _logger.LogInformation("Updating student with ID: {Id}", id);

        var student = await _repository.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Student with ID {id} not found.");

        // Check if email is taken by another student
        var emailOwner = await _repository.GetByEmailAsync(dto.Email);
        if (emailOwner != null && emailOwner.Id != id)
            throw new InvalidOperationException($"Email '{dto.Email}' is already used by another student.");

        student.Name = dto.Name;
        student.Email = dto.Email;
        student.Age = dto.Age;
        student.Course = dto.Course;

        await _repository.UpdateAsync(student);
        _logger.LogInformation("Student with ID {Id} updated successfully", id);
        return MapToDto(student);
    }

    public async Task<bool> DeleteStudentAsync(int id)
    {
        _logger.LogInformation("Deleting student with ID: {Id}", id);

        var exists = await _repository.ExistsAsync(id);
        if (!exists)
            throw new KeyNotFoundException($"Student with ID {id} not found.");

        var result = await _repository.DeleteAsync(id);
        _logger.LogInformation("Student with ID {Id} deleted successfully", id);
        return result;
    }

    private static StudentDto MapToDto(Student student) => new()
    {
        Id = student.Id,
        Name = student.Name,
        Email = student.Email,
        Age = student.Age,
        Course = student.Course,
        CreatedDate = student.CreatedDate
    };
}
