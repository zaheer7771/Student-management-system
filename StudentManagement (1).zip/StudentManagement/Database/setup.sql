-- ============================================================
--  Student Management System - Database Setup Script
--  Run this script in SQL Server Management Studio (SSMS)
--  or via sqlcmd before starting the application.
-- ============================================================

-- 1. Create the database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'StudentManagementDB')
BEGIN
    CREATE DATABASE StudentManagementDB;
    PRINT 'Database StudentManagementDB created.';
END
ELSE
    PRINT 'Database StudentManagementDB already exists.';
GO

USE StudentManagementDB;
GO

-- 2. Create the Students table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Students]') AND type = N'U')
BEGIN
    CREATE TABLE [dbo].[Students] (
        [Id]          INT           IDENTITY(1,1)   NOT NULL,
        [Name]        NVARCHAR(100)                 NOT NULL,
        [Email]       NVARCHAR(255)                 NOT NULL,
        [Age]         INT                           NOT NULL,
        [Course]      NVARCHAR(100)                 NOT NULL,
        [CreatedDate] DATETIME2(7)  DEFAULT GETUTCDATE() NOT NULL,

        CONSTRAINT [PK_Students]    PRIMARY KEY CLUSTERED ([Id] ASC),
        CONSTRAINT [UQ_Students_Email] UNIQUE ([Email]),
        CONSTRAINT [CK_Students_Age]   CHECK ([Age] BETWEEN 1 AND 120)
    );

    -- Index on Email for fast lookups
    CREATE NONCLUSTERED INDEX [IX_Students_Email]
        ON [dbo].[Students] ([Email]);

    -- Index on CreatedDate for sorted queries
    CREATE NONCLUSTERED INDEX [IX_Students_CreatedDate]
        ON [dbo].[Students] ([CreatedDate] DESC);

    PRINT 'Table Students created successfully.';
END
ELSE
    PRINT 'Table Students already exists.';
GO

-- 3. Seed sample data (only if table is empty)
IF NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[Students])
BEGIN
    INSERT INTO [dbo].[Students] ([Name], [Email], [Age], [Course], [CreatedDate])
    VALUES
        ('Ravi Sharma',    'ravi.sharma@example.com',    21, 'Computer Science',       GETUTCDATE()),
        ('Priya Patel',    'priya.patel@example.com',    22, 'Information Technology', GETUTCDATE()),
        ('Amit Verma',     'amit.verma@example.com',     20, 'Electronics Engineering',GETUTCDATE()),
        ('Sneha Kulkarni', 'sneha.kulkarni@example.com', 23, 'Mechanical Engineering', GETUTCDATE()),
        ('Rahul Singh',    'rahul.singh@example.com',    24, 'Civil Engineering',      GETUTCDATE());

    PRINT 'Sample data inserted successfully.';
END
ELSE
    PRINT 'Students table already has data; skipping seed.';
GO

-- 4. Verify
SELECT * FROM [dbo].[Students];
GO
