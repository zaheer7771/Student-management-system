using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using StudentManagement.Domain.Entities;
using StudentManagement.Repository.Interfaces;

namespace StudentManagement.Repository.Implementations;

public class StudentRepository : IStudentRepository
{
    private readonly string _connectionString;

    public StudentRepository(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
    }

    private SqlConnection CreateConnection() => new(_connectionString);

    public async Task<IEnumerable<Student>> GetAllAsync()
    {
        using var connection = CreateConnection();
        const string sql = "SELECT Id, Name, Email, Age, Course, CreatedDate FROM Students ORDER BY CreatedDate DESC";
        return await connection.QueryAsync<Student>(sql);
    }

    public async Task<Student?> GetByIdAsync(int id)
    {
        using var connection = CreateConnection();
        const string sql = "SELECT Id, Name, Email, Age, Course, CreatedDate FROM Students WHERE Id = @Id";
        return await connection.QueryFirstOrDefaultAsync<Student>(sql, new { Id = id });
    }

    public async Task<Student?> GetByEmailAsync(string email)
    {
        using var connection = CreateConnection();
        const string sql = "SELECT Id, Name, Email, Age, Course, CreatedDate FROM Students WHERE Email = @Email";
        return await connection.QueryFirstOrDefaultAsync<Student>(sql, new { Email = email });
    }

    public async Task<int> CreateAsync(Student student)
    {
        using var connection = CreateConnection();
        const string sql = @"
            INSERT INTO Students (Name, Email, Age, Course, CreatedDate)
            VALUES (@Name, @Email, @Age, @Course, @CreatedDate);
            SELECT CAST(SCOPE_IDENTITY() AS INT);";
        return await connection.QuerySingleAsync<int>(sql, student);
    }

    public async Task<bool> UpdateAsync(Student student)
    {
        using var connection = CreateConnection();
        const string sql = @"
            UPDATE Students 
            SET Name = @Name, Email = @Email, Age = @Age, Course = @Course
            WHERE Id = @Id";
        var rowsAffected = await connection.ExecuteAsync(sql, student);
        return rowsAffected > 0;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        using var connection = CreateConnection();
        const string sql = "DELETE FROM Students WHERE Id = @Id";
        var rowsAffected = await connection.ExecuteAsync(sql, new { Id = id });
        return rowsAffected > 0;
    }

    public async Task<bool> ExistsAsync(int id)
    {
        using var connection = CreateConnection();
        const string sql = "SELECT COUNT(1) FROM Students WHERE Id = @Id";
        var count = await connection.QuerySingleAsync<int>(sql, new { Id = id });
        return count > 0;
    }
}
