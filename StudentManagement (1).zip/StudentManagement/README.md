# 🎓 Student Management System
### ASP.NET Core Web API — Zest India IT Technical Assignment

A production-ready RESTful API built with **ASP.NET Core 8**, **Dapper**, **SQL Server**, and **JWT Authentication**, following clean layered architecture principles.

---

## 📐 Architecture

```
StudentManagement/
├── StudentManagement.API/           # Presentation layer (Controllers, Middleware)
│   ├── Controllers/
│   │   ├── AuthController.cs        # Login → JWT token
│   │   └── StudentsController.cs    # CRUD endpoints
│   ├── Extensions/
│   │   └── JwtTokenService.cs       # Token generation
│   └── Middleware/
│       └── GlobalExceptionHandlingMiddleware.cs
│
├── StudentManagement.Service/       # Business logic layer
│   ├── Interfaces/IStudentService.cs
│   └── Implementations/StudentService.cs
│
├── StudentManagement.Repository/    # Data access layer (Dapper + SQL Server)
│   ├── Interfaces/IStudentRepository.cs
│   └── Implementations/StudentRepository.cs
│
├── StudentManagement.Domain/        # Shared models, DTOs, Entities
│   ├── Entities/Student.cs
│   └── DTOs/StudentDtos.cs
│
├── StudentManagement.Tests/         # xUnit unit tests (Moq + FluentAssertions)
│   └── StudentServiceTests.cs
│
├── Database/
│   └── setup.sql                    # SQL Server setup script
├── Dockerfile
├── docker-compose.yml
└── README.md
```

---

## ✅ Features

| Feature | Details |
|---|---|
| **JWT Authentication** | Secure Bearer token login, configurable expiry |
| **Global Exception Handling** | Middleware maps exceptions → proper HTTP responses |
| **Logging** | Serilog — console + rolling file (`Logs/log-*.txt`) |
| **Swagger / OpenAPI** | Interactive docs at `http://localhost:<port>/` |
| **Layered Architecture** | Controller → Service → Repository → Database |
| **Input Validation** | Data annotations + model state validation |
| **Unit Tests** | xUnit, Moq, FluentAssertions |
| **Docker Support** | Dockerfile + docker-compose (API + SQL Server) |

---

## 🚀 Setup — Option A: Local (SQL Server installed)

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [SQL Server](https://www.microsoft.com/en-us/sql-server/sql-server-downloads) (Express or Developer edition)
- [SQL Server Management Studio](https://aka.ms/ssmsfullsetup) (optional)

### Step 1 — Clone the repository
```bash
git clone https://github.com/<your-username>/StudentManagement.git
cd StudentManagement
```

### Step 2 — Run the database script
Open **SQL Server Management Studio** or use `sqlcmd`, then run:
```bash
sqlcmd -S localhost -E -i Database/setup.sql
```
This creates the `StudentManagementDB` database, `Students` table, indexes, and seed data.

### Step 3 — Configure the connection string
Edit `StudentManagement.API/appsettings.json`:
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=StudentManagementDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```
> Use `User Id=sa;Password=...` for SQL authentication instead of `Trusted_Connection=True` if needed.

### Step 4 — Run the API
```bash
cd StudentManagement.API
dotnet run
```
Open your browser at **`http://localhost:5000`** (Swagger UI loads automatically).

---

## 🐳 Setup — Option B: Docker (no SQL Server needed)

### Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop)

### Run with docker-compose
```bash
docker-compose up --build
```
- API available at: `http://localhost:8080`
- SQL Server available at: `localhost:1433`

> The first run downloads the SQL Server image (~1.5 GB). Wait ~30 seconds for SQL Server to become healthy before the API connects.

---

## 🔑 Authentication

All `/api/students` endpoints are **protected** and require a Bearer token.

### 1. Get a token — POST `/api/auth/login`
```json
{
  "username": "admin",
  "password": "Admin@123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGci...",
    "expiry": "2025-01-01T01:00:00Z",
    "username": "admin"
  }
}
```

### 2. Use the token
Add the header to all student requests:
```
Authorization: Bearer eyJhbGci...
```

In Swagger UI — click **Authorize** (top right), paste `Bearer <your-token>`, click **Authorize**.

---

## 📡 API Endpoints

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| `POST` | `/api/auth/login` | Get JWT token | ❌ Public |
| `GET` | `/api/students` | Get all students | ✅ Required |
| `GET` | `/api/students/{id}` | Get student by ID | ✅ Required |
| `POST` | `/api/students` | Create new student | ✅ Required |
| `PUT` | `/api/students/{id}` | Update student | ✅ Required |
| `DELETE` | `/api/students/{id}` | Delete student | ✅ Required |

### Request body — Create/Update student
```json
{
  "name": "Ravi Sharma",
  "email": "ravi@example.com",
  "age": 21,
  "course": "Computer Science"
}
```

### Standard API Response format
```json
{
  "success": true,
  "message": "Student created successfully",
  "data": {
    "id": 1,
    "name": "Ravi Sharma",
    "email": "ravi@example.com",
    "age": 21,
    "course": "Computer Science",
    "createdDate": "2025-01-01T00:00:00Z"
  },
  "errors": null
}
```

---

## 🧪 Running Unit Tests

```bash
cd StudentManagement.Tests
dotnet test
```

Tests cover:
- `GetAllStudentsAsync` — returns all, returns empty
- `GetStudentByIdAsync` — found, not found
- `CreateStudentAsync` — success, duplicate email
- `UpdateStudentAsync` — success, not found, email conflict
- `DeleteStudentAsync` — success, not found

---

## ⚙️ Configuration Reference (`appsettings.json`)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "<SQL Server connection string>"
  },
  "JwtSettings": {
    "SecretKey": "<min 32 character secret key>",
    "Issuer": "StudentManagementAPI",
    "Audience": "StudentManagementClients",
    "ExpiryMinutes": "60"
  },
  "AdminCredentials": {
    "Username": "admin",
    "Password": "Admin@123"
  }
}
```

> ⚠️ **Never commit real secrets to GitHub.** Use environment variables or `dotnet user-secrets` in production.

---

## 🗄️ Database Schema

```sql
CREATE TABLE Students (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(100)     NOT NULL,
    Email       NVARCHAR(255)     NOT NULL UNIQUE,
    Age         INT               NOT NULL CHECK (Age BETWEEN 1 AND 120),
    Course      NVARCHAR(100)     NOT NULL,
    CreatedDate DATETIME2(7)      NOT NULL DEFAULT GETUTCDATE()
);
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Framework | ASP.NET Core 8 Web API |
| ORM / Data Access | Dapper |
| Database | SQL Server 2022 |
| Authentication | JWT Bearer (Microsoft.AspNetCore.Authentication.JwtBearer) |
| Logging | Serilog |
| Documentation | Swagger / Swashbuckle |
| Testing | xUnit, Moq, FluentAssertions |
| Containerization | Docker + docker-compose |

---

## 📝 Evaluation Checklist

- [x] CRUD APIs with proper HTTP status codes
- [x] JWT Authentication & secured endpoints
- [x] Global Exception Handling Middleware
- [x] Serilog logging (console + file)
- [x] Swagger documentation
- [x] Layered architecture (Controller → Service → Repository)
- [x] SQL Server with proper schema & indexes
- [x] Clean, structured, readable code
- [x] Unit tests (xUnit + Moq + FluentAssertions)
- [x] Docker support

---

*Built for the Zest India IT Pvt Ltd Full Stack Developer Technical Assignment.*
