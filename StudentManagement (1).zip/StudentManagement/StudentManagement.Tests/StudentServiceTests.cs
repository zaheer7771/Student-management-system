using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using StudentManagement.Domain.DTOs;
using StudentManagement.Domain.Entities;
using StudentManagement.Repository.Interfaces;
using StudentManagement.Service.Implementations;
using Xunit;

namespace StudentManagement.Tests;

public class StudentServiceTests
{
    private readonly Mock<IStudentRepository> _repositoryMock;
    private readonly Mock<ILogger<StudentService>> _loggerMock;
    private readonly StudentService _service;

    public StudentServiceTests()
    {
        _repositoryMock = new Mock<IStudentRepository>();
        _loggerMock = new Mock<ILogger<StudentService>>();
        _service = new StudentService(_repositoryMock.Object, _loggerMock.Object);
    }

    // ── GetAll ─────────────────────────────────────────────────────────────

    [Fact]
    public async Task GetAllStudentsAsync_ReturnsAllStudents()
    {
        // Arrange
        var students = new List<Student>
        {
            new() { Id = 1, Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS", CreatedDate = DateTime.UtcNow },
            new() { Id = 2, Name = "Bob",   Email = "bob@test.com",   Age = 22, Course = "IT", CreatedDate = DateTime.UtcNow }
        };
        _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync(students);

        // Act
        var result = await _service.GetAllStudentsAsync();

        // Assert
        result.Should().HaveCount(2);
        result.Should().Contain(s => s.Name == "Alice");
        result.Should().Contain(s => s.Name == "Bob");
    }

    [Fact]
    public async Task GetAllStudentsAsync_WhenNoStudents_ReturnsEmptyList()
    {
        _repositoryMock.Setup(r => r.GetAllAsync()).ReturnsAsync(new List<Student>());

        var result = await _service.GetAllStudentsAsync();

        result.Should().BeEmpty();
    }

    // ── GetById ────────────────────────────────────────────────────────────

    [Fact]
    public async Task GetStudentByIdAsync_WhenStudentExists_ReturnsStudent()
    {
        var student = new Student { Id = 1, Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS", CreatedDate = DateTime.UtcNow };
        _repositoryMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(student);

        var result = await _service.GetStudentByIdAsync(1);

        result.Should().NotBeNull();
        result!.Id.Should().Be(1);
        result.Name.Should().Be("Alice");
    }

    [Fact]
    public async Task GetStudentByIdAsync_WhenStudentNotFound_ReturnsNull()
    {
        _repositoryMock.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Student?)null);

        var result = await _service.GetStudentByIdAsync(99);

        result.Should().BeNull();
    }

    // ── Create ─────────────────────────────────────────────────────────────

    [Fact]
    public async Task CreateStudentAsync_WithValidData_ReturnsCreatedStudent()
    {
        var dto = new CreateStudentDto { Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS" };

        _repositoryMock.Setup(r => r.GetByEmailAsync(dto.Email)).ReturnsAsync((Student?)null);
        _repositoryMock.Setup(r => r.CreateAsync(It.IsAny<Student>())).ReturnsAsync(1);

        var result = await _service.CreateStudentAsync(dto);

        result.Should().NotBeNull();
        result.Name.Should().Be("Alice");
        result.Email.Should().Be("alice@test.com");
        result.Id.Should().Be(1);
    }

    [Fact]
    public async Task CreateStudentAsync_WithDuplicateEmail_ThrowsInvalidOperationException()
    {
        var dto = new CreateStudentDto { Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS" };
        var existing = new Student { Id = 5, Email = "alice@test.com" };

        _repositoryMock.Setup(r => r.GetByEmailAsync(dto.Email)).ReturnsAsync(existing);

        var act = async () => await _service.CreateStudentAsync(dto);

        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("*alice@test.com*");
    }

    // ── Update ─────────────────────────────────────────────────────────────

    [Fact]
    public async Task UpdateStudentAsync_WithValidData_ReturnsUpdatedStudent()
    {
        var existing = new Student { Id = 1, Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS", CreatedDate = DateTime.UtcNow };
        var dto = new UpdateStudentDto { Name = "Alice Updated", Email = "alice@test.com", Age = 21, Course = "IT" };

        _repositoryMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(existing);
        _repositoryMock.Setup(r => r.GetByEmailAsync(dto.Email)).ReturnsAsync(existing); // same student
        _repositoryMock.Setup(r => r.UpdateAsync(It.IsAny<Student>())).ReturnsAsync(true);

        var result = await _service.UpdateStudentAsync(1, dto);

        result.Should().NotBeNull();
        result.Name.Should().Be("Alice Updated");
        result.Age.Should().Be(21);
        result.Course.Should().Be("IT");
    }

    [Fact]
    public async Task UpdateStudentAsync_WhenStudentNotFound_ThrowsKeyNotFoundException()
    {
        _repositoryMock.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Student?)null);

        var dto = new UpdateStudentDto { Name = "X", Email = "x@test.com", Age = 20, Course = "CS" };
        var act = async () => await _service.UpdateStudentAsync(99, dto);

        await act.Should().ThrowAsync<KeyNotFoundException>()
            .WithMessage("*99*");
    }

    [Fact]
    public async Task UpdateStudentAsync_WithEmailTakenByAnotherStudent_ThrowsInvalidOperationException()
    {
        var existing = new Student { Id = 1, Name = "Alice", Email = "alice@test.com", Age = 20, Course = "CS" };
        var otherStudent = new Student { Id = 2, Email = "bob@test.com" };
        var dto = new UpdateStudentDto { Name = "Alice", Email = "bob@test.com", Age = 20, Course = "CS" };

        _repositoryMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(existing);
        _repositoryMock.Setup(r => r.GetByEmailAsync("bob@test.com")).ReturnsAsync(otherStudent);

        var act = async () => await _service.UpdateStudentAsync(1, dto);

        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("*bob@test.com*");
    }

    // ── Delete ─────────────────────────────────────────────────────────────

    [Fact]
    public async Task DeleteStudentAsync_WhenStudentExists_ReturnsTrue()
    {
        _repositoryMock.Setup(r => r.ExistsAsync(1)).ReturnsAsync(true);
        _repositoryMock.Setup(r => r.DeleteAsync(1)).ReturnsAsync(true);

        var result = await _service.DeleteStudentAsync(1);

        result.Should().BeTrue();
        _repositoryMock.Verify(r => r.DeleteAsync(1), Times.Once);
    }

    [Fact]
    public async Task DeleteStudentAsync_WhenStudentNotFound_ThrowsKeyNotFoundException()
    {
        _repositoryMock.Setup(r => r.ExistsAsync(99)).ReturnsAsync(false);

        var act = async () => await _service.DeleteStudentAsync(99);

        await act.Should().ThrowAsync<KeyNotFoundException>()
            .WithMessage("*99*");
    }
}
