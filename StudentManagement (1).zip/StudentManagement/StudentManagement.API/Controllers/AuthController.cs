using Microsoft.AspNetCore.Mvc;
using StudentManagement.API.Extensions;
using StudentManagement.Domain.DTOs;

namespace StudentManagement.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly IJwtTokenService _jwtTokenService;
    private readonly IConfiguration _configuration;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IJwtTokenService jwtTokenService, IConfiguration configuration, ILogger<AuthController> logger)
    {
        _jwtTokenService = jwtTokenService;
        _configuration = configuration;
        _logger = logger;
    }

    /// <summary>
    /// Authenticates a user and returns a JWT token.
    /// Default credentials: username = "admin", password = "Admin@123"
    /// </summary>
    [HttpPost("login")]
    [ProducesResponseType(typeof(ApiResponse<LoginResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status401Unauthorized)]
    public IActionResult Login([FromBody] LoginDto loginDto)
    {
        // In production, validate against a user store / database
        var validUsername = _configuration["AdminCredentials:Username"] ?? "admin";
        var validPassword = _configuration["AdminCredentials:Password"] ?? "Admin@123";

        if (loginDto.Username != validUsername || loginDto.Password != validPassword)
        {
            _logger.LogWarning("Failed login attempt for username: {Username}", loginDto.Username);
            return Unauthorized(ApiResponse<object>.FailureResponse("Invalid username or password."));
        }

        var token = _jwtTokenService.GenerateToken(loginDto.Username);
        var expiryMinutes = int.Parse(_configuration["JwtSettings:ExpiryMinutes"] ?? "60");

        var response = new LoginResponseDto
        {
            Token = token,
            Expiry = DateTime.UtcNow.AddMinutes(expiryMinutes),
            Username = loginDto.Username
        };

        _logger.LogInformation("User '{Username}' logged in successfully", loginDto.Username);
        return Ok(ApiResponse<LoginResponseDto>.SuccessResponse(response, "Login successful"));
    }
}
